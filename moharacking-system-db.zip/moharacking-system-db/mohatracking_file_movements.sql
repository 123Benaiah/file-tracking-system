-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: mohatracking
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `file_movements`
--

DROP TABLE IF EXISTS `file_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file_movements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `file_id` bigint unsigned NOT NULL,
  `sender_emp_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `intended_receiver_emp_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `actual_receiver_emp_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hand_carried_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivery_method` enum('internal_messenger','hand_carry','courier','email') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'internal_messenger',
  `sender_comments` text COLLATE utf8mb4_unicode_ci,
  `receiver_comments` text COLLATE utf8mb4_unicode_ci,
  `sent_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `received_at` timestamp NULL DEFAULT NULL,
  `acknowledged_at` timestamp NULL DEFAULT NULL,
  `movement_status` enum('sent','delivered','received','acknowledged','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'sent',
  `sla_days` int NOT NULL DEFAULT '3',
  `is_overdue` tinyint(1) NOT NULL DEFAULT '0',
  `qr_code` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `file_movements_file_id_movement_status_index` (`file_id`,`movement_status`),
  KEY `file_movements_sent_at_index` (`sent_at`),
  KEY `file_movements_received_at_index` (`received_at`),
  KEY `fm_intended_receiver_idx` (`intended_receiver_emp_no`),
  KEY `fm_sender_idx` (`sender_emp_no`),
  KEY `fm_actual_receiver_idx` (`actual_receiver_emp_no`),
  KEY `fm_movement_status_idx` (`movement_status`),
  CONSTRAINT `file_movements_actual_receiver_emp_no_foreign` FOREIGN KEY (`actual_receiver_emp_no`) REFERENCES `employees` (`employee_number`),
  CONSTRAINT `file_movements_file_id_foreign` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE CASCADE,
  CONSTRAINT `file_movements_intended_receiver_emp_no_foreign` FOREIGN KEY (`intended_receiver_emp_no`) REFERENCES `employees` (`employee_number`),
  CONSTRAINT `file_movements_sender_emp_no_foreign` FOREIGN KEY (`sender_emp_no`) REFERENCES `employees` (`employee_number`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-13 12:25:08
