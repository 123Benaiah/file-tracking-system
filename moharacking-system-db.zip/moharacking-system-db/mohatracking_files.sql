-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: localhost    Database: mohatracking
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `files`
--

DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_file_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_file_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_file_no` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` enum('normal','urgent','very_urgent') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'normal',
  `status` enum('at_registry','in_transit','received','under_review','action_required','completed','returned_to_registry','archived','merged') COLLATE utf8mb4_unicode_ci DEFAULT 'at_registry',
  `merged_into_file_id` bigint unsigned DEFAULT NULL,
  `merged_at` timestamp NULL DEFAULT NULL,
  `merged_by` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `merged_file_numbers` json DEFAULT NULL,
  `confidentiality` enum('public','confidential','secret') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'public',
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `due_date` date DEFAULT NULL,
  `date_registered` date NOT NULL,
  `current_holder` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registered_by` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `is_copy` tinyint(1) NOT NULL DEFAULT '0',
  `copy_number` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `files_new_file_no_unique` (`new_file_no`),
  KEY `files_status_current_holder_index` (`status`,`current_holder`),
  KEY `files_new_file_no_old_file_no_index` (`new_file_no`,`old_file_no`),
  KEY `files_due_date_index` (`due_date`),
  KEY `files_registered_by_index` (`registered_by`),
  KEY `files_original_file_no_copy_number_index` (`original_file_no`,`copy_number`),
  KEY `files_merged_into_file_id_foreign` (`merged_into_file_id`),
  KEY `files_date_registered_idx` (`date_registered`),
  KEY `files_priority_idx` (`priority`),
  KEY `files_current_holder_idx` (`current_holder`),
  CONSTRAINT `files_current_holder_foreign` FOREIGN KEY (`current_holder`) REFERENCES `employees` (`employee_number`) ON DELETE SET NULL,
  CONSTRAINT `files_merged_into_file_id_foreign` FOREIGN KEY (`merged_into_file_id`) REFERENCES `files` (`id`) ON DELETE SET NULL,
  CONSTRAINT `files_registered_by_foreign` FOREIGN KEY (`registered_by`) REFERENCES `employees` (`employee_number`)
) ENGINE=InnoDB AUTO_INCREMENT=2265 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-13 12:25:06
